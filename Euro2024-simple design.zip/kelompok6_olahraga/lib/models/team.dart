class Team {
  final String name;
  final String flag;
  int wins;
  int draws;
  int losses;
  int points;
  List<String> players;

  Team(this.name,
      {required this.flag,
      this.wins = 0,
      this.draws = 0,
      this.losses = 0,
      this.players = const []})
      : points = wins * 3 + draws * 1 + losses * 0;

  void updatePoints() {
    points = wins * 3 + draws * 1 + losses * 0;
  }
}
