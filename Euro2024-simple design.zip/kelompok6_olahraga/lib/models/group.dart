import 'team.dart';

class Group {
  final String name;
  final List<Team> _teams;

  Group(String name, List<Team> teams)
      : assert(name.isNotEmpty, 'Group name cannot be empty'),
        assert(teams.isNotEmpty, 'Teams list cannot be empty'),
        name = name,
        _teams = List.unmodifiable(teams);

  List<Team> get teams => _teams;
}
