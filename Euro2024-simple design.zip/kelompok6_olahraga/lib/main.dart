import 'package:flutter/material.dart';
import 'models/team.dart';
import 'models/group.dart';
import 'screens/bracket_page.dart';
import 'screens/schedule_page.dart';
import 'screens/group_page.dart';

void main() {
  runApp(EuroGroupApp());
}

class EuroGroupApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UEFA Euro Groups',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _currentIndex = 0;
  final List<Widget> _pages = [GroupPage(), BracketPage(), SchedulePage()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/images/euro_background.jpg',
              fit: BoxFit.cover,
            ),
          ),
          Positioned.fill(
            child: Column(
              children: [
                Expanded(
                  child: _pages[_currentIndex],
                ),
                BottomNavigationBar(
                  currentIndex: _currentIndex,
                  onTap: (index) {
                    setState(() {
                      _currentIndex = index;
                    });
                  },
                  items: [
                    BottomNavigationBarItem(
                      icon: Icon(Icons.group),
                      label: 'Groups',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.table_chart),
                      label: 'Bracket',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.schedule),
                      label: 'Schedule',
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
