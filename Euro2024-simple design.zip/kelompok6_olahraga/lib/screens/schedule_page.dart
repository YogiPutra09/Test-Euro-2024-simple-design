import 'package:flutter/material.dart';

class SchedulePage extends StatefulWidget {
  @override
  _SchedulePageState createState() => _SchedulePageState();
}

class _SchedulePageState extends State<SchedulePage> {
  List<Map<String, dynamic>> matches = [
    {
      "date": "15-06-2024",
      "team1": "Germany",
      "team2": "Scotland",
      "score1": "5",
      "score2": "1",
      "phase": "Group Stage",
    },
    {
      "date": "15-06-2024",
      "team1": "Hungary",
      "team2": "Switzerland",
      "score1": "1",
      "score2": "3",
      "phase": "Group Stage",
    },
    {
      "date": "15-06-2024",
      "team1": "Spain",
      "team2": "Croatia",
      "score1": "3",
      "score2": "0",
      "phase": "Group Stage",
    },
    {
      "date": "16-06-2024",
      "team1": "Italy",
      "team2": "Albania",
      "score1": "2",
      "score2": "1",
      "phase": "Group Stage",
    },
    {
      "date": "16-06-2024",
      "team1": "Poland",
      "team2": "Netherlands",
      "score1": "1",
      "score2": "2",
      "phase": "Group Stage",
    },
    {
      "date": "16-06-2024",
      "team1": "Slovenia",
      "team2": "Denmark",
      "score1": "1",
      "score2": "1",
      "phase": "Group Stage",
    },
    {
      "date": "17-06-2024",
      "team1": "Sebia",
      "team2": "England",
      "score1": "0",
      "score2": "1",
      "phase": "Group Stage",
    },
    {
      "date": "17-06-2024",
      "team1": "Belgium",
      "team2": "Slovakia",
      "score1": "0",
      "score2": "1",
      "phase": "Group Stage",
    },
    {
      "date": "17-06-2024",
      "team1": "Romania",
      "team2": "Ukraine",
      "score1": "3",
      "score2": "0",
      "phase": "Group Stage",
    },
    {
      "date": "18-06-2024",
      "team1": "Austria",
      "team2": "France",
      "score1": "0",
      "score2": "1",
      "phase": "Group Stage",
    },
    {
      "date": "18-06-2024",
      "team1": "Turkiye",
      "team2": "Georgia",
      "score1": "3",
      "score2": "1",
      "phase": "Group Stage",
    },
    {
      "date": "19-06-2024",
      "team1": "Portugal",
      "team2": "Czechia",
      "score1": "2",
      "score2": "1",
      "phase": "Group Stage",
    },
    {
      "date": "19-06-2024",
      "team1": "Germany",
      "team2": "Hungary",
      "score1": "2",
      "score2": "0",
      "phase": "Group Stage",
    },
    {
      "date": "19-06-2024",
      "team1": "Croatia",
      "team2": "Albania",
      "score1": "2",
      "score2": "2",
      "phase": "Group Stage",
    },
    {
      "date": "20-06-2024",
      "team1": "Scotland",
      "team2": "Switzerland",
      "score1": "1",
      "score2": "1",
      "phase": "Group Stage",
    },
    {
      "date": "20-06-2024",
      "team1": "Slovenia",
      "team2": "Serbia",
      "score1": "1",
      "score2": "1",
      "phase": "Group Stage",
    },
    {
      "date": "20-06-2024",
      "team1": "Denmark",
      "team2": "England",
      "score1": "1",
      "score2": "1",
      "phase": "Group Stage",
    },
    {
      "date": "21-06-2024",
      "team1": "Spain",
      "team2": "Italy",
      "score1": "1",
      "score2": "0",
      "phase": "Group Stage",
    },
    {
      "date": "21-06-2024",
      "team1": "Slovakia",
      "team2": "Ukraine",
      "score1": "1",
      "score2": "2",
      "phase": "Group Stage",
    },
    {
      "date": "21-06-2024",
      "team1": "Poland",
      "team2": "Austria",
      "score1": "1",
      "score2": "3",
      "phase": "Group Stage",
    },
    {
      "date": "22-06-2024",
      "team1": "Netherlands",
      "team2": "France",
      "score1": "0",
      "score2": "0",
      "phase": "Group Stage",
    },
    {
      "date": "22-06-2024",
      "team1": "Georgia",
      "team2": "Czechia",
      "score1": "1",
      "score2": "1",
      "phase": "Group Stage",
    },
    {
      "date": "22-06-2024",
      "team1": "Turkiye",
      "team2": "Portugal",
      "score1": "0",
      "score2": "3",
      "phase": "Group Stage",
    },
    {
      "date": "23-06-2024",
      "team1": "Belgium",
      "team2": "Romania",
      "score1": "2",
      "score2": "0",
      "phase": "Group Stage",
    },
    {
      "date": "24-06-2024",
      "team1": "Germany",
      "team2": "Switzerland",
      "score1": "1",
      "score2": "1",
      "phase": "Group Stage",
    },
    {
      "date": "24-06-2024",
      "team1": "Scotland",
      "team2": "Hungary",
      "score1": "0",
      "score2": "1",
      "phase": "Group Stage",
    },
    {
      "date": "25-06-2024",
      "team1": "Albania",
      "team2": "Spain",
      "score1": "0",
      "score2": "1",
      "phase": "Group Stage",
    },
    {
      "date": "25-06-2024",
      "team1": "Croatia",
      "team2": "Italy",
      "score1": "1",
      "score2": "1",
      "phase": "Group Stage",
    },
    {
      "date": "25-06-2024",
      "team1": "France",
      "team2": "Poland",
      "score1": "1",
      "score2": "1",
      "phase": "Group Stage",
    },
    {
      "date": "25-06-2024",
      "team1": "Netherlands",
      "team2": "Austria",
      "score1": "2",
      "score2": "3",
      "phase": "Group Stage",
    },
    {
      "date": "26-06-2024",
      "team1": "Denmark",
      "team2": "Serbia",
      "score1": "0",
      "score2": "0",
      "phase": "Group Stage",
    },
    {
      "date": "26-06-2024",
      "team1": "England",
      "team2": "Slovenia",
      "score1": "0",
      "score2": "0",
      "phase": "Group Stage",
    },
    {
      "date": "26-06-2024",
      "team1": "Slovakia",
      "team2": "Romania",
      "score1": "1",
      "score2": "1",
      "phase": "Group Stage",
    },
    {
      "date": "26-06-2024",
      "team1": "Ukraine",
      "team2": "Belgium",
      "score1": "0",
      "score2": "0",
      "phase": "Group Stage",
    },
    {
      "date": "27-06-2024",
      "team1": "Georgia",
      "team2": "Portugal",
      "score1": "2",
      "score2": "0",
      "phase": "Group Stage",
    },
    {
      "date": "27-06-2024",
      "team1": "Czechia",
      "team2": "Turkiye",
      "score1": "1",
      "score2": "2",
      "phase": "Group Stage",
    },
    {
      "date": "29-06-2024",
      "team1": "Switzerland",
      "team2": "Italy",
      "score1": "2",
      "score2": "0",
      "phase": "Round of 16",
    },
    {
      "date": "30-06-2024",
      "team1": "Germany",
      "team2": "Denmark",
      "score1": "2",
      "score2": "0",
      "phase": "Round of 16",
    },
    {
      "date": "30-06-2024",
      "team1": "England",
      "team2": "Slovakia",
      "score1": "2",
      "score2": "1",
      "phase": "Round of 16",
    },
    {
      "date": "01-07-2024",
      "team1": "Spain",
      "team2": "Georgia",
      "score1": "4",
      "score2": "1",
      "phase": "Round of 16",
    },
    {
      "date": "01-07-2024",
      "team1": "France",
      "team2": "Belgium",
      "score1": "1",
      "score2": "0",
      "phase": "Round of 16",
    },
    {
      "date": "02-07-2024",
      "team1": "Portugal",
      "team2": "Slovenia",
      "score1": "0(3)",
      "score2": "0(0)",
      "phase": "Round of 16",
    },
    {
      "date": "02-07-2024",
      "team1": "Romania",
      "team2": "Netherlands",
      "score1": "0",
      "score2": "3",
      "phase": "Round of 16",
    },
    {
      "date": "03-07-2024",
      "team1": "Austria",
      "team2": "Turkiye",
      "score1": "1",
      "score2": "2",
      "phase": "Round of 16",
    },
    {
      "date": "05-07-2024",
      "team1": "Spain",
      "team2": "Germany",
      "score1": "2",
      "score2": "1",
      "phase": "Quarter Final",
    },
    {
      "date": "06-07-2024",
      "team1": "Portugal",
      "team2": "France",
      "score1": "0(3)",
      "score2": "0(5)",
      "phase": "Quarter Final",
    },
    {
      "date": "06-07-2024",
      "team1": "England",
      "team2": "Switzerland",
      "score1": "1(5)",
      "score2": "1(3)",
      "phase": "Quarter Final",
    },
    {
      "date": "07-07-2024",
      "team1": "Netherlands",
      "team2": "Turkiye",
      "score1": "2",
      "score2": "1",
      "phase": "Quarter Final",
    },
    {
      "date": "10-07-2024",
      "team1": "Spain",
      "team2": "France",
      "score1": "2",
      "score2": "1",
      "phase": "Semi Final",
    },
    {
      "date": "11-07-2024",
      "team1": "Netherlands",
      "team2": "England",
      "score1": "1",
      "score2": "2",
      "phase": "Semi Final",
    },
    {
      "date": "15-07-2024",
      "team1": "Spain",
      "team2": "England",
      "score1": "2",
      "score2": "1",
      "phase": "Final",
    },
  ];

  void _showMatchDetails(int index) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title:
              Text('${matches[index]["team1"]} vs ${matches[index]["team2"]}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Date: ${matches[index]["date"]}'),
              SizedBox(height: 8),
              Text('Phase: ${matches[index]["phase"]}'),
              SizedBox(height: 8),
              Text(
                  'Score: ${matches[index]["score1"]} - ${matches[index]["score2"]}'),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Close'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Match Schedule'),
        backgroundColor: Color.fromARGB(
            255, 0, 94, 255), // Menambahkan warna teal pada header
      ),
      body: ListView.builder(
        itemCount: matches.length,
        itemBuilder: (context, index) {
          var match = matches[index];
          return Card(
            margin: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
            child: ListTile(
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "${match['team1']} vs ${match['team2']}",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    "${match['date']} - ${match['phase']}",
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
              trailing: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "${match['score1']} - ${match['score2']}",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
