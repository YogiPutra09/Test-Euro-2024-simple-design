import 'package:flutter/material.dart';
import '../models/team.dart';
import '../models/group.dart';

class GroupPage extends StatefulWidget {
  @override
  _GroupPageState createState() => _GroupPageState();
}

class _GroupPageState extends State<GroupPage> {
  final List<Group> groups = [
    Group('Group A', [
      Team('Germany',
          players: [
            'Manuel Neuer (GK)',
            'Joshua Kimmich (DF)',
            'Antonio Rudiger (DF)',
            'Nico Schlotterbeck (DF)',
            'David Raum (DF)',
            'Robert Andrich (MF)',
            'Toni Kroos (MF)',
            'Leroy Sané (MF)',
            'Ilkay Gundogan (MF)',
            'Jamal Musiala (MF)',
            'Kai Havertz (FW)'
          ],
          flag: 'assets/flags/germany.webp',
          wins: 2,
          draws: 1,
          losses: 0),
      Team('Hungary',
          players: [
            'Peter Gulacsi (GK)',
            'Marton Dardai (DF)',
            'Willi Orban (DF)',
            'Endre Botka (DF)',
            'Milos Kerkez (MF)',
            'Callum Styles (MF)',
            'Andras Schafer (MF)',
            'Bendeguz Bolla (MF)',
            'Roland Sallai (MF)',
            'Dominik Szoboszlai (MF)',
            'Barnabas Varga (FW)'
          ],
          flag: 'assets/flags/hungary.webp',
          wins: 1,
          draws: 0,
          losses: 2),
      Team('Scotland',
          players: [
            'Angus Gunn (GK)',
            'Jack Hendry (DF)',
            'Grant Hanley (DF)',
            'Kieran Tierney (DF)',
            'Anthony Ralston (DF)',
            'Andrew Robertson (DF)',
            'Billy Gilmour (MF)',
            'Callum McGregor (MF)',
            'Scott McTominay (MF)',
            'Ché Adams (FW)',
            'John McGinn (FW)'
          ],
          flag: 'assets/flags/scotland.png',
          wins: 0,
          draws: 1,
          losses: 2),
      Team('Switzerland',
          players: [
            'Yann Sommer (GK)',
            'Fabian Schär (DF)',
            'Manuel Akanji (DF)',
            'Ricardo Rodríguez (DF)',
            'Dan Ndoye (MF)',
            'Remo Freuler (MF)',
            'Granit Xhaka (MF)',
            'Michel Aebischer (MF)',
            'Fabian Rieder (MF)',
            'Ruben Vargas (MF)',
            'Breel Embolo (FW)'
          ],
          flag: 'assets/flags/swiss.webp',
          wins: 1,
          draws: 2,
          losses: 0),
    ]),
    Group('Group B', [
      Team('Spain',
          players: [
            'Unai Simón (GK)',
            'Dani Carvajal (DF)',
            'Robin Le Normand (DF)',
            'Aymeric Laporte (DF)',
            'Alejandro Grimaldo (DF)',
            'Pedri (MF)',
            'Rodri (MF)',
            'Fabián Ruiz (MF)',
            'Lamine Yamal (FW)',
            'Álvaro Morata (FW)',
            'Nico Williams (FW)'
          ],
          flag: 'assets/flags/spain.png',
          wins: 3,
          draws: 0,
          losses: 0),
      Team('Albania',
          players: [
            'Thomas Strakosha (GK)',
            'Iván Balliu (DF)',
            'Arlind Ajeti (DF)',
            'Berat Djimsiti (DF)',
            'Mario Mitaj (DF)',
            'Qazim Laçi (MF)',
            'Ylber Ramadani (MF)',
            'Kristjan Asllani (MF)',
            'Jasir Asani (FW)',
            'Rey Manaj (FW)',
            'Nedim Bajrami (FW)'
          ],
          flag: 'assets/flags/albania.webp',
          wins: 0,
          draws: 1,
          losses: 2),
      Team('Croatia',
          players: [
            'Dominik Livaković (GK)',
            'Josip Juranović (DF)',
            'Josip Šutalo (DF)',
            'Joško Gvardiol (DF)',
            'Ivan Perišić (DF)',
            'Luka Modrić (MF)',
            'Marcelo Brozović (MF)',
            'Mateo Kovačić (MF)',
            'Lovro Majer (FW)',
            'Bruno Petković (FW)',
            'Andrej Kramarić (FW)'
          ],
          flag: 'assets/flags/croatia.png',
          wins: 0,
          draws: 2,
          losses: 1),
      Team('Italy',
          players: [
            'Gianluigi Donnarumma (GK)',
            'Giovanni Di Lorenzo (DF)',
            'Alessandro Bastoni (DF)',
            'Riccardo Calafiori (DF)',
            'Federico Dimarco (DF)',
            'Davide Frattesi (MF)',
            'Jorginho (MF)',
            'Nicolò Barella (MF)',
            'Federico Chiesa (FW)',
            'Gianluca Scamacca (FW)',
            'Lorenzo Pellegrini (FW)'
          ],
          flag: 'assets/flags/italy.png',
          wins: 1,
          draws: 1,
          losses: 1),
    ]),
    Group('Group C', [
      Team('England',
          players: [
            'Jordan Pickford (GK)',
            'Kyle Walker (DF)',
            'John Stones (DF)',
            'Marc Guéhi (DF)',
            'Kieran Trippier (DF)',
            'Declan Rice (MF)',
            'Kobbie Mainoo (MF)',
            'Jude Bellingham (MF)',
            'Phil Foden (MF)',
            'Bukayo Saka (MF)',
            'Harry Kane (FW)'
          ],
          flag: 'assets/flags/england.png',
          wins: 1,
          draws: 2,
          losses: 0),
      Team('Denmark',
          players: [
            'Kasper Schmeichel (GK)',
            'Andreas Christensen (DF)',
            'Jannik Vestergaard (DF)',
            'Joachim Andersen (DF)',
            'Joakim Mæhle (DF)',
            'Alexander Bah (DF)',
            'Thomas Delaney (MF)',
            'Pierre-Emile Højbjerg (MF)',
            'Christian Eriksen (MF)',
            'Andreas Skov Olsen (FW)',
            'Rasmus Højlund (FW)'
          ],
          flag: 'assets/flags/denmark.png',
          wins: 0,
          draws: 3,
          losses: 0),
      Team('Slovenia',
          players: [
            'Jan Oblak (GK)',
            'Žan Karničnik (DF)',
            'Vanja Drkušić (DF)',
            'Jaka Bijol (DF)',
            'Erik Janža (DF)',
            'Petar Stojanović (MF)',
            'Adam Gnezda Čerin (MF)',
            'Timi Elšnik (MF)',
            'Jan Mlakar (MF)',
            'Andraž Šporar (FW)',
            'Benjamin Šeško (FW)'
          ],
          flag: 'assets/flags/slovenia.webp',
          wins: 0,
          draws: 3,
          losses: 0),
      Team('Serbia',
          players: [
            'Predrag Rajković (GK)',
            'Strahinja Pavlović (DF)',
            'Nikola Milenković (DF)',
            'Miloš Veljković (DF)',
            'Andrija Živković (MF)',
            'Nemanja Gudelj (MF)',
            'Ivan Ilić (MF)',
            'Srdjan Mijailović (MF)',
            'Saša Lukić (MF)',
            'Lazar Vujadin Samardzic (MF)',
            'Dušan Vlahović (FW)'
          ],
          flag: 'assets/flags/serbia.webp',
          wins: 0,
          draws: 2,
          losses: 1),
    ]),
    Group('Group D', [
      Team('France',
          players: [
            'Mike Maignan (GK)',
            'Theo Hernández (DF)',
            'William Saliba (DF)',
            'Dayot Upamecano (DF)',
            'Jules Koundé (DF)',
            'Eduardo Camavinga (MF)',
            'Aurélien Tchouameni (MF)',
            'N,Golo Kanté (MF)',
            'Antoine Griezmann (MF)',
            'Kylian Mbappé (FW)',
            'Marcus Thuram (FW)'
          ],
          flag: 'assets/flags/france.png',
          wins: 1,
          draws: 2,
          losses: 0),
      Team('Austria',
          players: [
            'Patrick Pentz (GK)',
            'Stefan Posch (DF)',
            'Kevin Danso (DF)',
            'Maximilian Wöber (DF)',
            'Phillipp Mwene (DF)',
            'Nicolas Seiwald (MF)',
            'Florian Grillitsch (MF)',
            'Konrad Laimer (MF)',
            'Christoph Baumgartner (MF)',
            'Marcel Sabitzer (MF)',
            'Michael Gregoritsch (FW)'
          ],
          flag: 'assets/flags/austria.png',
          wins: 2,
          draws: 0,
          losses: 1),
      Team('Netherlands',
          players: [
            'Bart Verbruggen (GK)',
            'Denzel Dumfries (DF)',
            'Stefan De Vrij (DF)',
            'Virgil van Dijk (DF)',
            'Nathan Aké (DF)',
            'Jerdy Schouten (MF)',
            'Tijjani Reijnders (MF)',
            'Xavi Simons (MF)',
            'Donyell Malen (FW)',
            'Memphis Depay (FW)',
            'Cody Gakpo (FW)'
          ],
          flag: 'assets/flags/netherlands.png',
          wins: 1,
          draws: 1,
          losses: 1),
      Team('Poland',
          players: [
            'Wojciech Szczęsny (GK)',
            'Nicola Zalewski (DF)',
            'Jakub Kiwior (DF)',
            'Paweł Dawidowicz (DF)',
            'Jan Bednarek (DF)',
            'Przemysław Frankowski (DF)',
            'Piotr Zieliński (MF)',
            'Jakub Moder (MF)',
            'Damian Szymański (MF)',
            'Robert Lewandowski (FW)',
            'Kacper Urbański (FW)'
          ],
          flag: 'assets/flags/poland.png',
          wins: 0,
          draws: 1,
          losses: 2),
    ]),
    Group('Group E', [
      Team('Belgium',
          players: [
            'Koen Casteels (GK)',
            'Arthur Theate (DF)',
            'Jan Vertonghen (DF)',
            'Wout Faes (DF)',
            'Timothy Castagne (DF)',
            'Jérémy Doku (MF)',
            'Kevin De Bruyne (MF)',
            'Amadou Onana (MF)',
            'Yannick Carrasco (MF)',
            'Loïs Openda (FW)',
            'Romelu Lukaku (FW)'
          ],
          flag: 'assets/flags/belgium.webp',
          wins: 1,
          draws: 1,
          losses: 1),
      Team('Romania',
          players: [
            'Florin Niță (GK)',
            'Nicușor Bancu (DF)',
            'Andrei Burcă (DF)',
            'Andrei Rațiu (DF)',
            'Marius Marin (MF)',
            'Florinel Coman (MF)',
            'Nicolae Stanciu (MF)',
            'Răzvan Marin (MF)',
            'Ianis Hagi (MF)',
            'Denis Drăguş (FW)'
          ],
          flag: 'assets/flags/romania.png',
          wins: 1,
          draws: 1,
          losses: 1),
      Team('Slovakia',
          players: [
            'Martin Dúbravka (GK)',
            'Peter Pekarík (DF)',
            'Denis Vavro (DF)',
            'Milan Škriniar (DF)',
            'Dávid Hancko (DF)',
            'Juraj Kucka (MF)',
            'Stanislav Lobotka (MF)',
            'Ondrej Duda (MF)',
            'Ivan Schranz (FW)',
            'David Strelec (FW)',
            'Lukáš Haraslín (FW)'
          ],
          flag: 'assets/flags/slovakia.png',
          wins: 1,
          draws: 1,
          losses: 1),
      Team('Ukraine',
          players: [
            'Andriy Lunin (GK)',
            'Oleksandr Tymchyk (DF)',
            'Illia Zabarnyi (DF)',
            'Oleksandr Svatok (DF)',
            'Mykola Matviyenko (DF)',
            'Oleksandr Zinchenko (DF)',
            'Mykola Shaparenko (MF)',
            'Volodymyr Brazhko (MF)',
            'Georgiy Sudakov (MF)',
            'Artem Dovbyk (FW)',
            'Mykhailo Mudryk (FW)'
          ],
          flag: 'assets/flags/ukraine.png',
          wins: 1,
          draws: 1,
          losses: 1),
    ]),
    Group('Group F', [
      Team('Portugal',
          players: [
            'Diogo Costa (GK)',
            'João Cancelo (DF)',
            'Rúben Dias (DF)',
            'Pepe (DF)',
            'Nuno Mendes (DF)',
            'Vitinha (MF)',
            'João Palhinha (MF)',
            'Bernardo Silva (MF)',
            'Bruno Fernandes (MF)',
            'Rafael Leão (MF)',
            'Cristiano Ronaldo (FW)'
          ],
          flag: 'assets/flags/portugal.webp',
          wins: 2,
          draws: 0,
          losses: 1),
      Team('Turkey',
          players: [
            'Mert Günok (GK)',
            'Ferdi Kadıoğlu (DF)',
            'Abdülkerim Bardakcı (DF)',
            'Samet Akaydin (DF)',
            'Kaan Ayhan (DF)',
            'Mert Müldür (DF)',
            'Kenan Yıldız (MF)',
            'Hakan Çalhanoğlu (MF)',
            'Salih Özcan (MF)',
            'Arda Güler (MF)',
            'Barış Alper Yılmaz (FW)'
          ],
          flag: 'assets/flags/turkey.webp',
          wins: 2,
          draws: 0,
          losses: 1),
      Team('Czech Republic',
          players: [
            'Jindřich Staněk (GK)',
            'Ladislav Krejčí (DF)',
            'Robin Hranáč (DF)',
            'Tomáš Holeš (DF)',
            'Tomáš Souček (MF)',
            'Pavel Šulc (MF)',
            'Lukáš Provod (MF)',
            'David Douděra (MF)',
            'Vladimír Coufal (MF)',
            'Jan Kuchta (FW)',
            'Patrik Schick (FW)'
          ],
          flag: 'assets/flags/czech.webp',
          wins: 0,
          draws: 1,
          losses: 2),
      Team('Georgia',
          players: [
            'Giorgi Mamardashvili (GK)',
            'Otar Kakabadze (DF)',
            'Giorgi Gvelesiani (DF)',
            'Guram Kashia (DF)',
            'Lasha Dvali (DF)',
            'Luka Lochoshvili (DF)',
            'Giorgi Chakvetadze (MF)',
            'Otar Kiteishvili (MF)',
            'Giorgi Kochorashvili (MF)',
            'Georges Mikautadze (FW)',
            'Khvicha Kvaratskhelia (FW)'
          ],
          flag: 'assets/flags/georgia.webp',
          wins: 1,
          draws: 1,
          losses: 1),
    ]),
  ];

  void _editTeamStats(Team team) {
    TextEditingController winsController =
        TextEditingController(text: team.wins.toString());
    TextEditingController drawsController =
        TextEditingController(text: team.draws.toString());
    TextEditingController lossesController =
        TextEditingController(text: team.losses.toString());

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Edit Stats for ${team.name}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildTextField(winsController, 'Wins'),
              _buildTextField(drawsController, 'Draws'),
              _buildTextField(lossesController, 'Losses'),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                setState(() {
                  team.wins = int.tryParse(winsController.text) ?? team.wins;
                  team.draws = int.tryParse(drawsController.text) ?? team.draws;
                  team.losses =
                      int.tryParse(lossesController.text) ?? team.losses;
                  team.updatePoints();
                });
                Navigator.of(context).pop();
              },
              child: Text('Save'),
            ),
          ],
        );
      },
    );
  }

  Widget _buildTextField(TextEditingController controller, String label) {
    return TextField(
      controller: controller,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(labelText: label),
    );
  }

  void _showTeamPlayers(Team team) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Players of ${team.name}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: team.players.map((player) => Text(player)).toList(),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Close'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Groups'),
        backgroundColor: Color.fromARGB(255, 0, 94, 255),
      ),
      body: ListView.builder(
        padding: EdgeInsets.all(10.0),
        itemCount: groups.length,
        itemBuilder: (context, index) {
          return Card(
            elevation: 4,
            margin: EdgeInsets.symmetric(vertical: 10),
            child: ExpansionTile(
              leading: Icon(Icons.group, color: Colors.teal),
              title: Text(groups[index].name,
                  style: TextStyle(fontWeight: FontWeight.bold)),
              children: groups[index].teams.map<Widget>((team) {
                return ListTile(
                  leading: Image.asset(team.flag, width: 30),
                  title: Text(team.name,
                      style: TextStyle(fontWeight: FontWeight.w500)),
                  subtitle: Text(
                      '${team.wins} Wins, ${team.draws} Draws, ${team.losses} Losses'),
                  trailing: Icon(Icons.arrow_forward, color: Colors.teal),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => TeamDetailPage(team: team),
                      ),
                    );
                  },
                );
              }).toList(),
            ),
          );
        },
      ),
    );
  }
}

class TeamDetailPage extends StatelessWidget {
  final Team team;

  TeamDetailPage({required this.team});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(team.name),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Image.asset(team.flag, width: 50),
                SizedBox(width: 10),
                Text(
                  team.name,
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            SizedBox(height: 20),
            Text(
              'Players:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: team.players.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    leading: Icon(Icons.person, color: Colors.teal),
                    title: Text(team.players[index]),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
