import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: BracketPage(),
  ));
}

class MatchResult {
  final String winner;
  final String loser;
  final int scoreWinner;
  final int scoreLoser;
  final List<String> goalScorersWinner;
  final List<String> goalScorersLoser;
  final int possession1;
  final int possession2;
  final int shotsOnTarget1;
  final int shotsOnTarget2;
  final int fouls1;
  final int fouls2;

  MatchResult({
    required this.winner,
    required this.loser,
    required this.scoreWinner,
    required this.scoreLoser,
    required this.goalScorersWinner,
    required this.goalScorersLoser,
    this.possession1 = 0,
    this.possession2 = 0,
    this.shotsOnTarget1 = 0,
    this.shotsOnTarget2 = 0,
    this.fouls1 = 0,
    this.fouls2 = 0,
  });
}

class BracketPage extends StatefulWidget {
  @override
  _BracketPageState createState() => _BracketPageState();
}

class _BracketPageState extends State<BracketPage> {
  final List<Map<String, dynamic>> roundOf16 = [
    {
      "team1": "Spain",
      "team2": "Georgia",
      "score1": '4',
      "score2": '1',
      "goalScorers1": [
        "Rodri (39)",
        "Fabian Ruiz (51)",
        "Nico Williams (75)",
        "Dani Olmo (83)"
      ],
      "goalScorers2": ["Robin Le Normand (18)(OG)"],
      "possession1": 60,
      "possession2": 40,
      "shotsOnTarget1": 8,
      "shotsOnTarget2": 3,
      "fouls1": 10,
      "fouls2": 15,
    },
    {
      "team1": "Germany",
      "team2": "Denmark",
      "score1": '2',
      "score2": '0',
      "goalScorers1": ["Kai Havertz (53)(Pen)", "Jamal Musiala (68)"],
      "goalScorers2": [],
      "possession1": 55,
      "possession2": 45,
      "shotsOnTarget1": 9,
      "shotsOnTarget2": 2,
      "fouls1": 7,
      "fouls2": 15,
    },
    {
      "team1": "Portugal",
      "team2": "Slovenia",
      "score1": '0(3)',
      "score2": '0(0)',
      "goalScorers1": [
        "Cristiano Ronaldo (Pen)",
        "Bruno Fernandes (Pen)",
        "Bernardo Silva (Pen)"
      ],
      "goalScorers2": [],
      "possession1": 73,
      "possession2": 27,
      "shotsOnTarget1": 6,
      "shotsOnTarget2": 2,
      "fouls1": 8,
      "fouls2": 17,
    },
    {
      "team1": "France",
      "team2": "Belgium",
      "score1": '1',
      "score2": '0',
      "goalScorers1": ["Jan Vertonghen (85)(OG)"],
      "goalScorers2": [],
      "possession1": 56,
      "possession2": 44,
      "shotsOnTarget1": 2,
      "shotsOnTarget2": 2,
      "fouls1": 7,
      "fouls2": 10,
    },
    {
      "team1": "Romania",
      "team2": "Netherlands",
      "score1": '0',
      "score2": '3',
      "goalScorers1": [],
      "goalScorers2": [
        "Cody Gakpo (20)",
        "Donyell Malen (83)",
        "Donyell Malen (90+3)"
      ],
      "possession1": 35,
      "possession2": 65,
      "shotsOnTarget1": 1,
      "shotsOnTarget2": 6,
      "fouls1": 8,
      "fouls2": 9,
    },
    {
      "team1": "Austria",
      "team2": "Turkey",
      "score1": '1',
      "score2": '2',
      "goalScorers1": ["Michael Gregoritsch (66)"],
      "goalScorers2": ["Merih Demiral (1)", "Merih Demiral (59)"]
    },
    {
      "team1": "England",
      "team2": "Slovakia",
      "score1": '2',
      "score2": '1',
      "goalScorers1": ["Jude Bellingham (90+5)", "Harry Kane (91)"],
      "goalScorers2": ["Ivan Schranz (25)"],
      "possession1": 61,
      "possession2": 39,
      "shotsOnTarget1": 5,
      "shotsOnTarget2": 3,
      "fouls1": 12,
      "fouls2": 5,
    },
    {
      "team1": "Switzerland",
      "team2": "Italy",
      "score1": '2',
      "score2": '0',
      "goalScorers1": ["Remo Freuler (37)", "Ruben Vargas (46)"],
      "goalScorers2": [],
      "possession1": 49,
      "possession2": 51,
      "shotsOnTarget1": 4,
      "shotsOnTarget2": 1,
      "fouls1": 9,
      "fouls2": 15,
    },
  ];

  final List<Map<String, dynamic>> quarterFinals = [
    {
      "team1": "Spain",
      "team2": "Germany",
      "score1": '2',
      "score2": '1',
      "goalScorers1": ["Dani Olmo (51)", "Mikel Merino (119)"],
      "goalScorers2": ["Florian Wirtz (89)"],
      "possession1": 48,
      "possession2": 52,
      "shotsOnTarget1": 6,
      "shotsOnTarget2": 5,
      "fouls1": 17,
      "fouls2": 22,
    },
    {
      "team1": "Portugal",
      "team2": "France",
      "score1": '0(3)',
      "score2": '0(5)',
      "goalScorers1": [
        "Cristiano Ronaldo (Pen)",
        "Bernardo Silva (Pen)",
        "Nuno Mendes (Pen)"
      ],
      "goalScorers2": [
        "Ousmane Dembele (Pen)",
        "Youssouf Fofana (Pen)",
        "Jules Kounde (Pen)",
        "Bradley Barcola (Pen)",
        "Theo Hernandez (Pen)"
      ],
      "possession1": 60,
      "possession2": 40,
      "shotsOnTarget1": 4,
      "shotsOnTarget2": 5,
      "fouls1": 8,
      "fouls2": 13,
    },
    {
      "team1": "England",
      "team2": "Switzerland",
      "score1": '1(5)',
      "score2": '1(3)',
      "goalScorers1": [
        "Bukayo Saka (80)",
        "Cole Palmer (Pen)",
        "Jude Bellingham (Pen)",
        "Bukayo Saka (Pen)",
        "Ivan Toney (Pen)",
        "Trent Alexander Arnold (Pen)"
      ],
      "goalScorers2": [
        "Breel Embolo (75)",
        "Fabian Schar (Pen)",
        "Xherdan Shaqiri (Pen)",
        "Zeki Amdouni (Pen)"
      ],
      "possession1": 52,
      "possession2": 48,
      "shotsOnTarget1": 3,
      "shotsOnTarget2": 3,
      "fouls1": 8,
      "fouls2": 13,
    },
    {
      "team1": "Netherlands",
      "team2": "Turkey",
      "score1": '4',
      "score2": '1',
      "goalScorers1": ["Stefan De Vrij (70)", "Mert Muldur (76)(OG)"],
      "goalScorers2": ["Samet Akaydin (35)"],
      "possession1": 60,
      "possession2": 40,
      "shotsOnTarget1": 8,
      "shotsOnTarget2": 3,
      "fouls1": 10,
      "fouls2": 15,
    }
  ];

  final List<Map<String, dynamic>> semiFinals = [
    {
      "team1": "Spain",
      "team2": "France",
      "score1": '2',
      "score2": '1',
      "goalScorers1": ["Lamine Yamal (21)", "Dani Olmo (25)"],
      "goalScorers2": ["Randal Kolo Muani (9)"],
      "possession1": 59,
      "possession2": 41,
      "shotsOnTarget1": 2,
      "shotsOnTarget2": 3,
      "fouls1": 9,
      "fouls2": 14,
    },
    {
      "team1": "England",
      "team2": "Netherlands",
      "score1": '2',
      "score2": '1',
      "goalScorers1": ["Harry Kane (18)(Pen)", "Ollie Watkins (90)"],
      "goalScorers2": ["Xavi Simons (7)"],
      "possession1": 41,
      "possession2": 59,
      "shotsOnTarget1": 2,
      "shotsOnTarget2": 5,
      "fouls1": 11,
      "fouls2": 6,
    },
  ];

  final List<Map<String, dynamic>> finals = [
    {
      "team1": "Spain",
      "team2": "England",
      "score1": '2',
      "score2": '1',
      "goalScorers1": ["Nico Williams (47)", "Mikel Oyarzabal (86)"],
      "goalScorers2": ["Cole Palmer (73)"],
      "possession1": 66,
      "possession2": 34,
      "shotsOnTarget1": 6,
      "shotsOnTarget2": 4,
      "fouls1": 11,
      "fouls2": 5,
    },
  ];

  List<MatchResult?> matchResults = List.filled(15, null);
  bool isSpainWinnerCelebrating = false;

  @override
  void initState() {
    super.initState();
    // Simulasi merayakan kemenangan Spanyol setelah delay 2 detik
    Future.delayed(Duration(seconds: 1), () {
      setState(() {
        isSpainWinnerCelebrating = true;
      });
    });
  }

  void _showGoalScorersDialog(String team1, String team2,
      List<String> goalScorers1, List<String> goalScorers2) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(
            'Goal Scorers',
            style: TextStyle(color: Colors.white), // Warna teks putih
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '$team1:',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold), // Warna teks putih
              ),
              ...goalScorers1
                  .map((scorer) => Text(
                        scorer,
                        style:
                            TextStyle(color: Colors.white), // Warna teks putih
                      ))
                  .toList(),
              SizedBox(height: 16),
              Text(
                '$team2:',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold), // Warna teks putih
              ),
              ...goalScorers2
                  .map((scorer) => Text(
                        scorer,
                        style:
                            TextStyle(color: Colors.white), // Warna teks putih
                      ))
                  .toList(),
            ],
          ),
          backgroundColor: Colors.black, // Warna background dialog
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text(
                'Close',
                style: TextStyle(color: Colors.white), // Warna teks putih
              ),
            ),
          ],
        );
      },
    );
  }

  Widget buildBracket(String title, List<Map<String, dynamic>> matches) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            title,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.white, // Warna teks putih
            ),
          ),
        ),
        ...matches.asMap().entries.map((entry) {
          int index = entry.key;
          Map<String, dynamic> match = entry.value;

          String team1 = match["team1"];
          String team2 = match["team2"];
          String score1 = match["score1"] ?? '0';
          String score2 = match["score2"] ?? '0';
          List<String> goalScorers1 =
              List<String>.from(match["goalScorers1"] ?? []);
          List<String> goalScorers2 =
              List<String>.from(match["goalScorers2"] ?? []);
          int possession1 = match["possession1"] ?? 0;
          int possession2 = match["possession2"] ?? 0;
          int shotsOnTarget1 = match["shotsOnTarget1"] ?? 0;
          int shotsOnTarget2 = match["shotsOnTarget2"] ?? 0;
          int fouls1 = match["fouls1"] ?? 0;
          int fouls2 = match["fouls2"] ?? 0;

          int score1Int =
              int.tryParse(score1.replaceAll(RegExp(r'\D'), '')) ?? 0;
          int score2Int =
              int.tryParse(score2.replaceAll(RegExp(r'\D'), '')) ?? 0;

          return GestureDetector(
            onTap: () => _showGoalScorersDialog(
                team1, team2, goalScorers1, goalScorers2),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: Container(
                padding: const EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.teal),
                  borderRadius: BorderRadius.circular(8.0),
                  color: Colors.black.withOpacity(0.6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Column(
                        children: [
                          Text(
                            '$team1 ($score1)',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: score1Int > score2Int
                                  ? FontWeight.bold
                                  : FontWeight.normal,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            'Possession: $possession1%',
                            style: TextStyle(color: Colors.white),
                          ),
                          Text(
                            'Shots on Target: $shotsOnTarget1',
                            style: TextStyle(color: Colors.white),
                          ),
                          Text(
                            'Fouls: $fouls1',
                            style: TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Text(
                        'vs',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.teal,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Column(
                        children: [
                          Text(
                            '$team2 ($score2)',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: score2Int > score1Int
                                  ? FontWeight.bold
                                  : FontWeight.normal,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            'Possession: $possession2%',
                            style: TextStyle(color: Colors.white),
                          ),
                          Text(
                            'Shots on Target: $shotsOnTarget2',
                            style: TextStyle(color: Colors.white),
                          ),
                          Text(
                            'Fouls: $fouls2',
                            style: TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }).toList(),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Bracket',
          style: TextStyle(color: Colors.white), // Warna teks putih
        ),
        backgroundColor:
            Color.fromARGB(255, 0, 94, 255), // Warna latar belakang app bar
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/euro_background.webp'),
            fit: BoxFit.cover,
            colorFilter: ColorFilter.mode(
              Colors.black.withOpacity(0.5), // Menambahkan efek gelap
              BlendMode.darken,
            ),
          ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              buildBracket('Round of 16', roundOf16),
              Divider(thickness: 2.0, color: Colors.teal),
              buildBracket('Quarter Finals', quarterFinals),
              Divider(thickness: 2.0, color: Colors.teal),
              buildBracket('Semi Finals', semiFinals),
              Divider(thickness: 2.0, color: Colors.teal),
              buildBracket('Final', finals),
            ],
          ),
        ),
      ),
    );
  }
}
