package com.example.project_uas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
